install node

npm install

<!-- install mongodb -->
sudo apt-get install mongodb
<!-- start mongodb server -->
sudo service mongodb start
<!-- Stop MongoDB -->
sudo service mongodb stop

install ffmpeg
