{
  "results": [
    {
      "alternatives": [
        {
          "confidence": 0.909,
          "transcript": "more than half a century man and boy I've been picking over the Australian political scene like in August on the garbage bin "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.827,
          "transcript": "and now it is with the hot both heavy and light that I approached the microphone for what is the last time looking back at the political week and the last time on it is "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.848,
          "transcript": "I am at the end of forty two years as a journalist which began on a summer Monday morning at the end of nineteen seventy five when I walked into Rupert Murdoch's news limited building took the list to the fourth floor turned left and left into the petition newsroom of The Daily Telegraph and joined in but was then in part the demolition of the few remaining shattered pots the Hoff pillars of the Whitlam government the telly was then in hot pursuit of the cam Lani Lund's affair "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.891,
          "transcript": "looking back on the political path of the last four decades I think "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.915,
          "transcript": "surprise was my most consistent response the big surprise first of the dismissal was followed by sequential surprises at an ever exhilarated speed of the revolving door on the prime minister's office "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.909,
          "transcript": "and then there's the more general surprise at the broad direction of politics here and internationally "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.864,
          "transcript": "the Whitlam revolution seemed to set public life off in one direction with big government putting society on the course which would see vast numbers going to fee free universities universal public health care and the biggest challenge looked like being choosing an adult education course to round out the ever shortening working week "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.877,
          "transcript": "and then came the Thatcher Reagan revolution the neo liberal agenda took over and the political world moved in a different direction "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.941,
          "transcript": "right now the direction seems to be shifting again with the neo liberal free trade lower taxes trickle down arguments not carry the day from the United Kingdom to the United States "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.771,
          "transcript": "Australia's political will this week became a little clearer or the likely cost for the next election became clearer with bill shorten setting out labor's broad direction equality "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.881,
          "transcript": "the key issue at the center tax a key tool to that end "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.781,
          "transcript": "it's not fair for instance when a young couple Webster that parents go and beat on a house on the site by their first time and it compatriot investor who's receiving tax by concessions the government response is to portray labor as turning to tax as the solution to all problems and being the enemy of business "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.78,
          "transcript": "Scott Morrison it will show it was given up on crushed in the economy E. doesn't think it strains can do better by their wives is increasing by the economy growing but business is doing better "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.687,
          "transcript": "the bill shorten now it's all about how a child's adopt not heavy grows the I have a rule economy "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.813,
          "transcript": "he's playing heavily into this this idea of envy "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.802,
          "transcript": "and he sighing quite bluntly to Australians that he doesn't have any plans to grow the economy and he just wants to have a discussion about Herzl divvied up so what does bill shouldn't say when he's asked how he's going to promote growth how he'll achieve that key objective confidences will boost economic activity and what those confidence for example is making sure that whatever we spend money we spend it on infrastructure which is job creating not by heading away big unsustainable corporate "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.881,
          "transcript": "to lodge profitable "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.434,
          "transcript": "it's Pullman bank "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.642,
          "transcript": "its profits "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.997,
          "transcript": "confidence "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.763,
          "transcript": "might have to work on that as a source of economic dynamism bill shorten is really the weak heart in labour's financial Dick hit Chris bone with that sort of question and heal machine gun policy options back at you ask Andrew Lee and wet behind before not full but bill shorten might one of which appears on responses "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.83,
          "transcript": "that's the battle ahead between now and the election next year or maybe twenty nineteen and on current sittings that's a labor win those sittings can change but they can also remain the same ask John held he in PT Castillo threw everything against the wall throughout the two thousand and seven period without ever affecting the voters view that it was Kevin Rudd's turn so on the evidence now a labor win "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.905,
          "transcript": "but as the physicist kneels board noted prediction is very difficult "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.905,
          "transcript": "especially if it's about the future "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.884,
          "transcript": "what you can do after forty two years in journalism is looked back and there is a seeming consensus that it was better then never quite sure when then was but clearly confidence in government the quality of politicians the media public debate voter involvement political parties "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.902,
          "transcript": "there are much worse now "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.992,
          "transcript": "really "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.884,
          "transcript": "I think the past gets off lightly the first big issue in my memory is the Vietnam War in the nineteen sixties and I was deeply skeptical then about what the government which government Menzies hold "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.884,
          "transcript": "not really sure about what the government was saying on the war and my skepticism was well based you straight in government laud its way into the wall following the lead of president Lyndon Johnson his escalation of the war was based on the lies of the client Gulf of Tonkin incident "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.848,
          "transcript": "over the decades will be managed by men overwhelmingly men variable abilities and the best general description is still the Donald Horne thesis it out in his book the lucky country the destroyed was a naturally blessed land lead generally by mediocrity is "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.913,
          "transcript": "although that may be too harsh dealing with blessings is in itself no small achievement the world is littered with naturally blessed lands that have made a hash of the good fortune "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.837,
          "transcript": "politics matters and Australia gets what a pass maybe a credit "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.827,
          "transcript": "life is hard for governments now in many ways the media cycle often pointed to certainly nobody's going to last as leader for the men's he sixteen years or even the hell a decade "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.858,
          "transcript": "but those long terms were not the simple as they look in retrospect both leaders were lucky they earned their luck through earlier travails "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.953,
          "transcript": "but the big and you difficulty here and around the western world in recent years has been the economy and for voters when considering what is the number one issue it is always the economy stupid "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.77,
          "transcript": "as James carvel advise Bill Clinton "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.825,
          "transcript": "years ago John Howard faced plenty of buffeting indulges in his time he could easily have lost elections let's not get carried away with the belief that he sailed on smooth waters for more than a decade there's plenty of chop luck played a big part in his longevity but the held years had a big structural advantage broadly the voters thought though doing fairly well they were better off in the prospects were for the kids to do even better that's changed wages are going no where but backwards for most house prices spiral and for most that's a curse more than a blessing well corporate profits a booming "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.903,
          "transcript": "but as always feel less than enthusiasm for governments make them less well off in fact and they become out right truculent and incumbents reduced to a single argument the other mob would be even worse "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.889,
          "transcript": "incumbency is in that context of burden and if you're putting money on the coalition for the next election you be looking for all odds "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.876,
          "transcript": "and finally as an indulgence in my final look at politics I might nominate my favorite politician maybe favorite leader and my pick the goes to "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.885,
          "transcript": "John Howard liberal prime minister gets my personal endorsement for the very personal reason that he was a politician who believed in turning up and arguing his case there are other politicians in that heavy cat agree so the choice is a bit of a tree but John Howard this politician and prime minister when he was one who never viewed interviewers as allies but he always believed in facing them and his record shows that he was pretty good at it and it was good to interview too he put his case forcefully but he didn't try to turn an interview into a monologue there are those in political ranks now who think they should only talk to people who agree with them who defied the media between friends and enemies "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.916,
          "transcript": "me I like to think of all politicians equally "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.777,
          "transcript": "enemies antagonism is a much better basis for all a political interview the nineteen us "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.943,
          "transcript": "the listener can lose out when interviewer and interviewee "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.442,
          "transcript": "I chums "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.823,
          "transcript": "a good interview was always been a great pleasure in waking life I'll miss them and much besides but these exhilaration about life ahead now to so with the best of wishes to colleagues and above all to you the listener "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.999,
          "transcript": "it's time to say good morning "
        }
      ],
      "final": true
    },
    {
      "alternatives": [
        {
          "confidence": 0.958,
          "transcript": "goodbye "
        }
      ],
      "final": true
    }
  ],
  "result_index": 0
}
