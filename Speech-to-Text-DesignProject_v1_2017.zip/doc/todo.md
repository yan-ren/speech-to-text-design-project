STUDY:
1.  js anyc callback function
https://www.youtube.com/watch?v=YxWMxJONp7E&list=PL4cUxeGkcC9jAhrjtZ9U93UMIhnCc44MH

2.  js mutiple callback function

3.  Video transcription tool
https://medium.com/glitch-digital/preview-of-a-video-transcription-tool-452e043daef5?from=groupmessage&isappinstalled=0

TODO:
1.  ISSUE long file translation
https://blog.robseder.com/2013/10/18/executing-a-long-running-process-from-a-web-page/

2.  split file listing view(translated vs non-translated)
    sorting files based on timestamp

3.  Google API English/French   

FUTURE:
1.  split file

2.  convert video

TESTING:
1.  setup testing structure for db, frontend js and backend controllers

2.  test with large file.
    currently has been tested with:  mp3 44s 691kb

    api sends file and receives result longer than response timeout
      idea: frontend adds progress bar for showing backend running process status
      https://www.codeproject.com/Articles/34072/Displaying-a-Progress-Bar-Loading-Box-During-any-T
