# Speech-to-Text-DesignProject
